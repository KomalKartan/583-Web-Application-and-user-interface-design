﻿using System;

namespace LAB02
{
    public class Program
    {
        public static void Main(string[] args)
        {
            double singlePrescriptionGlasses = 40.00;
            double nonPrescriptionGlasses = 25.00;
            double antiGlare = 12.50;
            double brownTint = 9.99;
            double totalCost;
            string i;
            string j;
            Console.WriteLine("What kind of glasses would you like:");

            do
            {
                Console.WriteLine("1-> prescription, 2-> non-prescription: ");
                i = Console.ReadLine();
            }
            while ((i != "1") && (i != "2"));

            Console.WriteLine("What kind of coating would you like:");

            do
            {
                Console.WriteLine("1-> anti-glare, 2-> brown-tint: ");
                j = Console.ReadLine();
            }
            while ((j != "1") && (j != "2"));


            if(i == "1")
            {
                if (j == "1")
                {
                    totalCost = singlePrescriptionGlasses + antiGlare;
                    Console.WriteLine("Prescription glasses with anti-glare");
                    Console.WriteLine("Total Cost is: " + totalCost);
                }
                else
                {
                    totalCost = singlePrescriptionGlasses + brownTint;
                    Console.WriteLine("Prescription glasses with brown tint");
                    Console.WriteLine("Total Cost is: " + totalCost);
                }
            }
            else
            {
                if (j == "1")
                {
                    totalCost = nonPrescriptionGlasses + antiGlare;
                    Console.WriteLine("Non-Prescription glasses with anti-glare");
                    Console.WriteLine("Total Cost is: " + totalCost);
                }
                else
                {
                    totalCost = nonPrescriptionGlasses + brownTint;
                    Console.WriteLine("Non-Prescription glasses with brown tint");
                    Console.WriteLine("Total Cost is: " + totalCost);
                }
            }
        }
    }
}
