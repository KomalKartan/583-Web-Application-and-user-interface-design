"use strict";

/*var $ = function (id) {
    return document.getElementById(id);
};*/

$(document).ready(function() {
	var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
    document.getElementById("arrival_date").focus();
    
   $("#submit").click(
    function(){
        $("#reservation_form").submit();
    }
    );
    
    $("#reservation_form").submit(
        function(event){
            
           var isValid = true;
            
            //validate email address
            
            var email = $("#email").val().trim();
            var arrival_date = $("#arrival_date").val().trim();
            var nights = $("#nights").val().trim();
            var name = $("#name").val().trim();
            var phone = $("#phone").val().trim();
            
            if(email == ""){
              
                $("#email").next().text("This field is required");
                isValid = false;
            }
            else if(!emailPattern.test(email)){
                $("#email").next().text("Must be a valid email address.");
                isValid = false;
                
            }
            else{
                $("#email").next().text("");
            }
            $("#email").val(email);
            
            
            //validating arrival date
            if(arrival_date == ""){
                
                $("#arrival_date").next().text("This field is required");
                isValid = false;
            }
            else if(isNaN(arrival_date) == true){
                
                $("#arrival_date").next().text("Enter a valid date");
                isValid = false;
            }
            else{
                $("#arrival_date").next().text("");
            }
            $("arrival_date").val(arrival_date);
            
            //validating nights
            if(nights == ""){
                $("#nights").next().text("This field is required");
                isValid = false;
            }
            else if(isNaN(nights) == true){
                
                $("#nights").next().text("Must be a numeric");
                isValid = false;
            }
            else{
               
                $("#nights").next().text("");
            }
            $("#nights").val(nights);
            
            //validating name
            if(name == ""){
                $("#name").next().text("This field is required");
                isValid = false;
            }
            else{
                $("#name").next().text("");
            }
            $("name").val(name);
            
            
            //validating phone
            var lengthofno = 10;
            
            if(phone == ""){
                $("#phone").next().text("This field is required");
                isValid = false;
            }
            else if(isNaN(phone) == true){
                
                $("#phone").next().text("Enter valid phone number");
                isValid = false;
            }     
            else if(phone.length != lengthofno){
               $("#phone").next().text("Enter valid 10 digit phone number");
                isValid = false; 
            }
            else{
               
                $("#phone").next().text("");
            }
            $("phone").val(phone);
            
            
            //prevents form from submission
            if(isValid == false){
                event.preventDefault();
            }
        }); //end submit
		
}); // end ready



